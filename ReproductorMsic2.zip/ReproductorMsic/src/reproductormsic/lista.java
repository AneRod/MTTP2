/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reproductormsic;

/**
 *
 * @author USER
 */


/**
 *
 * @author USER
 */
public class lista {
    nodo first;
    nodo last;
    
    public static int tam;
    
    public lista(){
    first = null;
    last = null;
    tam = 0;
    
    }
    
    public boolean isEmpty(){
        return first == null && last == null;
     
    }
    
    public void clear(){
        while(!isEmpty()){
            borrar(first);
        }
    }
    
    public void insertar(String nombre, String direccion){
        nodo nuevo = new nodo(nombre,direccion);
        
        if(first == null){
            first = nuevo;
            first.siguiente = first;
            nuevo.anterior = last;
            last = nuevo;
        }else{
            last.siguiente = nuevo;
            nuevo.siguiente = first;
            nuevo.anterior = last;
            last = nuevo;
            first.anterior = last;
        
        }
        tam++;
    }
    
    public int size(){
        if(isEmpty()){
            return 0;
        }else{
        return tam;
        }
    }
    
    public int index(nodo b){
        nodo aux = first;
        int con = 0;
        do{
         if(aux == b){
             return con;
         }else{
             aux = aux.siguiente;
             con++;
         }
        }while (aux != first);
        return -1; 
    }
    
    public nodo getCancion(int index){
        if(index < 0 || index >= tam){
            return null;
        }
        
        int n = 0;
        nodo aux = first;
        while(n != index){
            aux = aux.siguiente;
            n++;
        }
        return aux;
    }
    
public void borrar(nodo d) {
        boolean encontrado = false;
        nodo actual = first;
        nodo anterior = last;
        do {
            if (actual == d) {
                if (actual == first) {
                    first = first.siguiente;
                    last.siguiente = first;
                    first.anterior = last;
                } else if (actual == last) {
                    last = anterior;
                    first.anterior = last;
                    last.siguiente = first;
                } else {
                    anterior.siguiente = actual.siguiente;
                    actual.siguiente.anterior = anterior;
                }
                encontrado = true;
                tam--; // Decrementar el tamaño de la lista
            }
            anterior = actual;
            actual = actual.siguiente;
        } while (actual != first && !encontrado);
    }
public int getIndice(nodo buscado) {
    nodo actual = first;
    int indice = 0;
    while (actual != null) {
        if (actual == buscado) {
            return indice;
        }
        actual = actual.siguiente;
        indice++;
    }
    return -1;
}
}