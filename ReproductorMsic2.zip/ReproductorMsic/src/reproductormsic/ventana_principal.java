
package reproductormsic;


import java.io.File;
import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javafx.embed.swing.JFXPanel; // Necesario para inicializar JavaFX en Swing
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import java.util.Random;
import java.awt.Color;



public class ventana_principal extends javax.swing.JFrame {
  private final lista list = new lista(); // Lista de canciones
    private nodo actual = null; // Nodo actual en reproducción
    private MediaPlayer mediaPlayer = null; // Reproductor de JavaFX
    private DefaultListModel<String> listaModelo = new DefaultListModel<>();
    private boolean modoAleatorio = false;
    private Random random = new Random();
    // Constructor
public ventana_principal() {
    new JFXPanel(); // Inicializa JavaFX
    initComponents();
    setTitle("Reproductor de Música MP3");
    setResizable(false);
    setLocationRelativeTo(null);
    lista_can.setModel(listaModelo);                                                                                                                         
    jSlider1.setMinimum(0); // Mínimo valor para el slider de volumen
    jSlider1.setMaximum(100); // Máximo valor para el slider de volumen
    jSlider1.setValue(50); // Valor predeterminado (volumen medio)

    // Añadir el ListSelectionListener aquí
   lista_can.addMouseListener(new java.awt.event.MouseAdapter() {
    @Override
    public void mouseClicked(java.awt.event.MouseEvent evt) {
        // Verifica si el evento es un doble clic
        if (evt.getClickCount() == 2) {
            // Obtiene el índice del elemento que fue doble clic
            int selectedIndex = lista_can.locationToIndex(evt.getPoint());
            if (selectedIndex != -1) { // Verifica que el índice sea válido
                nodo selectedNode = list.getCancion(selectedIndex);
                if (selectedNode != null) {
                    actual = selectedNode; // Actualiza el nodo actual
                    reproducirCancion(actual.direccion); // Reproduce la canción seleccionada
                }
            }
        }
    }
});
}
//    
   private void reproducirCancion(String direccion) {
   try {
        if (mediaPlayer != null) {
            // Solo detenemos si no estamos en modo "stop"
            if (mediaPlayer.getStatus() != MediaPlayer.Status.STOPPED) {
                mediaPlayer.stop();
            }
            // No llamamos a dispose() aquí para mantener los recursos
        }
        
        Media media = new Media(new File(direccion).toURI().toString());
        mediaPlayer = new MediaPlayer(media);
        mediaPlayer.setVolume(jSlider1.getValue() / 100.0);
        
        // Listener para cuando termine la canción
        mediaPlayer.setOnEndOfMedia(() -> {
            if (modoAleatorio) {
                reproducirCancionAleatoria();
            } else if (actual != null && actual.siguiente != null) {
                actual = actual.siguiente;
                reproducirCancion(actual.direccion);
            }
        });
        
        mediaPlayer.play();
        nombre_can.setText(new File(direccion).getName());
        
        // Resaltar en la lista
        int index = list.getIndice(actual);
        if (index != -1) {
            lista_can.setSelectedIndex(index);
            lista_can.ensureIndexIsVisible(index);
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al reproducir: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
    }
}


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        anterior = new javax.swing.JButton();
        play = new javax.swing.JButton();
        siguiente = new javax.swing.JButton();
        jSlider1 = new javax.swing.JSlider();
        agregar = new javax.swing.JButton();
        eliminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        lista_can = new javax.swing.JList<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        nombre_can = new javax.swing.JTextArea();
        Aleatorio = new javax.swing.JButton();
        detener = new javax.swing.JButton();

        jButton1.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        anterior.setText("anterior");
        anterior.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                anteriorActionPerformed(evt);
            }
        });

        play.setText("Play ");
        play.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                playActionPerformed(evt);
            }
        });

        siguiente.setText("siguiente");
        siguiente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                siguienteActionPerformed(evt);
            }
        });

        jSlider1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSlider1StateChanged(evt);
            }
        });

        agregar.setText("agregar cancion");
        agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarActionPerformed(evt);
            }
        });

        eliminar.setText("quitar cancion");
        eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarActionPerformed(evt);
            }
        });

        lista_can.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(lista_can);

        nombre_can.setColumns(20);
        nombre_can.setRows(5);
        nombre_can.setText(".....");
        jScrollPane2.setViewportView(nombre_can);

        Aleatorio.setText("Aleatorio");
        Aleatorio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AleatorioActionPerformed(evt);
            }
        });

        detener.setText("detener cancion");
        detener.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                detenerActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(78, 78, 78)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(75, 75, 75)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(agregar)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 369, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(eliminar))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(detener)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(43, 43, 43)
                                    .addComponent(jSlider1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(anterior)
                                    .addGap(29, 29, 29)
                                    .addComponent(play)
                                    .addGap(32, 32, 32)
                                    .addComponent(siguiente)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(Aleatorio)
                                .addGap(211, 211, 211)))
                        .addGap(45, 45, 45)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(agregar)
                    .addComponent(eliminar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(anterior)
                    .addComponent(play)
                    .addComponent(siguiente))
                .addGap(29, 29, 29)
                .addComponent(Aleatorio)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addComponent(detener)
                .addGap(34, 34, 34)
                .addComponent(jSlider1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(48, 48, 48))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void anteriorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_anteriorActionPerformed
      if (actual != null && actual.anterior != null) {
            actual = actual.anterior;
            reproducirCancion(actual.direccion);
        } else {
            JOptionPane.showMessageDialog(this, "No hay más canciones en la lista.",
                    "Información", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_anteriorActionPerformed

    private void agregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarActionPerformed
   JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new FileNameExtensionFilter("Archivos de Audio (MP3, WAV, WMA)", "mp3", "wav", "wma"));
        fileChooser.setMultiSelectionEnabled(true);
        int resultado = fileChooser.showOpenDialog(this);

        if (resultado == JFileChooser.APPROVE_OPTION) {
            File[] archivos = fileChooser.getSelectedFiles();
            for (File archivo : archivos) {
                list.insertar(archivo.getName(), archivo.getAbsolutePath());
                listaModelo.addElement(archivo.getName());
            }
        }
        
    }//GEN-LAST:event_agregarActionPerformed

    private void playActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_playActionPerformed
         if (mediaPlayer != null) {
        MediaPlayer.Status estado = mediaPlayer.getStatus();

        switch (estado) {
            case PLAYING:
                mediaPlayer.pause();
                break;
            case PAUSED:
            case STOPPED:
            case READY:
                mediaPlayer.play();
                break;
            default:
                break;
        }
    }
    }//GEN-LAST:event_playActionPerformed

    private void siguienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_siguienteActionPerformed
       if (actual != null && actual.siguiente != null) {
            actual = actual.siguiente;
            reproducirCancion(actual.direccion);
        } else {
            JOptionPane.showMessageDialog(this, "No hay más canciones en la lista.",
                    "Información", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_siguienteActionPerformed

    private void detenerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_detenerActionPerformed
      if (mediaPlayer != null) {
            mediaPlayer.stop();
            nombre_can.setText("...");
        }
    }//GEN-LAST:event_detenerActionPerformed

    private void jSlider1StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSlider1StateChanged
if (mediaPlayer != null) {
        // Convertir el valor del slider (0 a 100) a una escala de volumen (0.0 a 1.0)
        double volumen = jSlider1.getValue() / 100.0;
        mediaPlayer.setVolume(volumen); // Ajustar el volumen del MediaPlayer
    }
    }//GEN-LAST:event_jSlider1StateChanged


    private void eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarActionPerformed
    int indice = lista_can.getSelectedIndex();
    if (indice != -1) {
        String nombreCancion = listaModelo.getElementAt(indice);
        
        // Mostrar diálogo de confirmación
        int respuesta = JOptionPane.showConfirmDialog(
            this,
            "¿Deseaeliminar la canción \"" + nombreCancion + "\"?",
            "Confirmar eliminación",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );
        
        // Solo eliminar si el usuario confirma
        if (respuesta == JOptionPane.YES_OPTION) {
            nodo nodoAEliminar = list.getCancion(indice);
            listaModelo.remove(indice);
            list.borrar(nodoAEliminar);
            // Si la canción eliminada estaba en reproducción, detenerla
            if (actual == nodoAEliminar) {
                detenerActionPerformed(null);
                actual = null; // Reiniciar referencia
            }
        }
    } else {
        JOptionPane.showMessageDialog(this, 
            "Selecciona una canción para eliminar.",
            "Advertencia", 
            JOptionPane.WARNING_MESSAGE);
    }
    }//GEN-LAST:event_eliminarActionPerformed

    private void AleatorioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AleatorioActionPerformed
   modoAleatorio = !modoAleatorio;
    
    if (modoAleatorio) {
        Aleatorio.setBackground(new Color(0, 180, 0));
        Aleatorio.setForeground(Color.WHITE);
        Aleatorio.setText("ALEATORIO ON");
        
        // Si no hay canción reproduciéndose, empezar una aleatoria
        if (mediaPlayer == null || mediaPlayer.getStatus() != MediaPlayer.Status.PLAYING) {
            reproducirCancionAleatoria();
        }
    } else {
        Aleatorio.setBackground(null);
        Aleatorio.setForeground(null);
        Aleatorio.setText("ALEATORIO OFF");
    } 
    }//GEN-LAST:event_AleatorioActionPerformed
    private void reproducirCancionAleatoria() {
    if (listaModelo.isEmpty()) {
        JOptionPane.showMessageDialog(this, 
            "La lista de reproducción está vacía", 
            "Advertencia", JOptionPane.WARNING_MESSAGE);
        return;
    }
    
    int nuevoIndice;
    do {
        nuevoIndice = random.nextInt(listaModelo.size());
    } while (listaModelo.size() > 1 && 
             list.getCancion(nuevoIndice) == actual); // Evitar repetir la misma
    
    actual = list.getCancion(nuevoIndice);
    reproducirCancion(actual.direccion);

    /**
     * @param args the command line arguments
     */
    } public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ventana_principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ventana_principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ventana_principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ventana_principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
       java.awt.EventQueue.invokeLater(() -> {
            new ventana_principal().setVisible(true);
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Aleatorio;
    private javax.swing.JButton agregar;
    private javax.swing.JButton anterior;
    private javax.swing.JButton detener;
    private javax.swing.JButton eliminar;
    private javax.swing.JButton jButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSlider jSlider1;
    private javax.swing.JList<String> lista_can;
    private javax.swing.JTextArea nombre_can;
    private javax.swing.JButton play;
    private javax.swing.JButton siguiente;
    // End of variables declaration//GEN-END:variables
}

