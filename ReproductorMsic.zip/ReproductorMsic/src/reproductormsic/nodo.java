/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reproductormsic;

/**
 *
 * @author USER
 */
public class nodo {
    String nombre;
    String direccion;
    nodo siguiente;
    nodo anterior;
        public nodo(String nombre, String direccion){
            this.nombre = nombre;
            this.direccion = direccion;
            //apuntadres
            siguiente = null;
            anterior = null;
        }
}
